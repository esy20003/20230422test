-- 10_JOIN.sql

-- JOIN
-- 두개이상의 테이블에 나눠져 있는 관련 데이터들을 하나의 테이블로 모아서 조회하고자 할때 사용하는 명령입니다.

--[1] 이름 Douglas Grant 인 사원이  근무하는 부서명을  출력하고자 한다면...
select department_id from employees where emp_name='Douglas Grant';
-- 위명령을 실행후 얻어진 부서번호로 아래와 같이 부서번호 검색하여 부서명을 알아냅니다
select department_name   from departments where department_id=50;

-- 위의 두개의 명령을 하나의 명형으로 합해주는 역할을 join 명령이 실행합니다
--[2] join : 두개이상의 테이블에 나뉘어 져 있는 데이터를 한번의 sql문으로 원하는 결과를 얻습니다


--cross join : 두개 이상의 테이블이 조인될때 where절에 의해 공통되는 컬럼에 의한 결합이 발생하지 않는 경우 
-- * 가장 최악의 결과를 얻는 조인 방식
-- A 테이블과 B 테이블의 cross join 된다면
-- A테이블의 1번 레코드와 B테이블의 모든 레코드와 하나하나 모두 조합
-- A테이블의 2번 레코드와 B테이블의 모든 레코드와 하나하나 모두  조합
-- A테이블의 3번 레코드와 B테이블의 모든 레코드와 하나하나 모두  조합
-- ....

create table A(
a1 varchar2(5),
a2 varchar2(5),
a3 varchar2(5)
);
create table B(
b1 varchar2(5),
b2 varchar2(5),
b3 varchar2(5)
);
insert into  A values('ar1', 'ar1', 'ar1');
insert into  A values('ar2', 'ar2', 'ar2');
insert into  A values('ar3', 'ar3', 'ar3');
delete from B;
insert into  B values('br1', 'br1', 'ar1');
insert into  B values('br2', 'br2', 'ar2');
insert into  B values('br3', 'br3', 'ar3');
insert into  B values('br4', 'br4', 'ar3');

select * from A;
select * from B;

-- cross조인 : 별도의 조건이나 키워드 없이 from 뒤에 테이블이름을 컴마로 구분해서 두개이상쓰면 cross 조인이 됩니다
select * from A, B;


-- A테이블의 레코드가 8개, B테이블의 레코드가 7개 라면 총 크로스조인의 결과 레코드수는 8x7 = 56
-- A테이블의 필드가 8개, B테이블의 필드가 3개 라면 총 크로스조인의 결과 필드수는 8+3 = 11
 select * from dept   -- 레코드 4, 필드 3
 select * from emp  -- 레코드 14, 필드 8

 -- 크로스 조인 
select * from dept, emp   -- 레코드 56, 필드 11

--equi join : 조인 대상이 되는 두테이블에서 공통적으로 존재하는 컬럼의 값이 일치하는 행을 연결하여 결과를 생성
select * from dept, emp where emp.deptno = dept.deptno;














