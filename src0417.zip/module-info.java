/**
 * 
 */
/**
 * @author JAVA01
 *
 */
module Oracle_Project {
	requires java.sql;
}